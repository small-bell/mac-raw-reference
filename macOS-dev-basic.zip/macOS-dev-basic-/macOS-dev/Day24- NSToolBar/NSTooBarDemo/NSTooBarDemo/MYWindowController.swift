//
//  MYWindowController.swift
//  NSTooBarDemo
//
//  Created by Alexcai on 2017/8/28.
//  Copyright © 2017年 Alexcai. All rights reserved.
//

import Cocoa

class MYWindowController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
    
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
//    @IBAction func clickMyToolBarItem(_ sender: Any) {
//        print("点击了window的item")
//    }

}
