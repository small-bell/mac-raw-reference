# NSToolBar  : 工具栏控件

* 显示位置: 窗口的的标题栏下面
* 支持用户定义
* 在Storyboard中的两种添加方式

