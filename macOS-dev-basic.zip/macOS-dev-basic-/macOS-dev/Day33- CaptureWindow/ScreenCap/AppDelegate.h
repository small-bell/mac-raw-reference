//
//  AppDelegate.h
//  ScreenCap
//
//  Created by Alexcai on 2018/10/3.
//  Copyright © 2018 dongjiu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

