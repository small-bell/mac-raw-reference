//
//  ViewController.m
//  ScreenCap
//
//  Created by Alexcai on 2018/10/3.
//  Copyright © 2018 dongjiu. All rights reserved.
//

#import "ViewController.h"


@class WWCaptureWindowController;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}
- (void)mouseDown:(NSEvent *)event{
//    id Controller = NSClassFromString(@"WWCaptureWindowController");
//    NSWindowController *vc = [[Controller alloc]init];
//    [vc showWindow:nil];
    
}


@end
