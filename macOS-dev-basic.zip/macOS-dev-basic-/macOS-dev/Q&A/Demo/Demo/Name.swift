//
//  Name.swift
//  Demo
//
//  Created by Daredake on 2017/10/6.
//  Copyright © 2017年 Daredake. All rights reserved.
//

import Cocoa

class Name: NSObject {
    var name: String

    init(name: String) {
        self.name = name
    }
}
