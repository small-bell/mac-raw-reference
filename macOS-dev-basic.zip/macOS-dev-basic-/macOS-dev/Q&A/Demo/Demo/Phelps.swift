//
//  Phelps.swift
//  Demo
//
//  Created by Daredake on 2017/10/6.
//  Copyright © 2017年 Daredake. All rights reserved.
//

import Cocoa

class Phelps: NSObject {
    var matchP: String
    var recordP: String

    init(matchP: String, recordP: String) {
        self.matchP = matchP
        self.recordP = recordP
    }
}
