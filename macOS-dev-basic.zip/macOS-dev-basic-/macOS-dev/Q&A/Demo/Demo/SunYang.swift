//
//  SunYang.swift
//  Demo
//
//  Created by Daredake on 2017/10/6.
//  Copyright © 2017年 Daredake. All rights reserved.
//

import Cocoa

class SunYang: NSObject {
    var matchS: String
    var recordS: String

    init(matchS: String, recordS: String) {
       self.matchS = matchS
       self.recordS = recordS
    }
}
