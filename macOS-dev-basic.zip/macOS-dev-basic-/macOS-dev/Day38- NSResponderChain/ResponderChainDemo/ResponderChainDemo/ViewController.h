//
//  ViewController.h
//  ResponderChainDemo
//
//  Created by Alexcai on 2019/3/25.
//  Copyright © 2019 dongjiu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

