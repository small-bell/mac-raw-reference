//
//  XCResponseView.m
//  ResponderChainDemo
//
//  Created by Alexcai on 2019/3/26.
//  Copyright © 2019 dongjiu. All rights reserved.
//

#import "XCResponseView.h"

@implementation XCResponseView

//- (void)mouseDown:(NSEvent *)event{
//    NSLog(@"%s",__FUNCTION__);
//}
//- (BOOL)acceptsFirstResponder{
//    return YES;
//}

@end
