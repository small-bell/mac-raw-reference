//
//  XCResponseView.h
//  ResponderChainDemo
//
//  Created by Alexcai on 2019/3/26.
//  Copyright © 2019 dongjiu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface XCResponseView : NSView

@end

NS_ASSUME_NONNULL_END
