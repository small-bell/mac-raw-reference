# Day38
![](https://img.shields.io/badge/language-Swift-orange.svg)
![](https://img.shields.io/badge/platform-macOS-lightgrey.svg)

NSResponder Chain  
[Mac开发跬步积累(六): 响应链NSResponder Chain](https://www.jianshu.com/p/039cfe2e5ef7)
