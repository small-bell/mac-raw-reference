# XCWallpaper
![](https://img.shields.io/badge/language-Objc-orange.svg)
![](https://img.shields.io/badge/platform-macOS-lightgrey.svg)

set wallpaper for Mac OSX
