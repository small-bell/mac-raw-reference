//
//  ViewController.swift
//  Cocoa&OpenGL
//
//  Created by Alexcai on 2018/5/6.
//  Copyright © 2018年 Alexcai. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


}

