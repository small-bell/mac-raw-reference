# 结束语

* 感谢
   * 23种常用类
   * 库管理
   * 上架相关


* 遗漏 

![](https://ws1.sinaimg.cn/large/006tNc79gy1fj6823qpjqj312g154h4d.jpg)
 

* 后续:

    >  综合项目实战视频(计划中) 

