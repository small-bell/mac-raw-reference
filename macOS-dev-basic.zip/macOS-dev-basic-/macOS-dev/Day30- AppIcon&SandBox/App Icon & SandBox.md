### App Icon

* 避免使用圆角矩形
* 尽量与App 内容相关（否则可能会被拒审）
* App Icon size

### SandBox
* 上架App必须开启
* 设置相应的权限
   * 网络
   * 硬件
   * 文件路径

> 示例Demo : 创建文件夹   

* 应用内权限
* 永久权限