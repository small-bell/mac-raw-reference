# NSArrayController : (Cocoa Binding 中用于管理数组到控制器)


* arrangedObjects : 表示数组中整个对象的集合

* selection : 选中的对象

> 要使用这些属性,可以将它们用做Bind时的控制器键  