//
//  Student.swift
//  NSArrayControllerDemo
//
//  Created by Alexcai on 2017/8/30.
//  Copyright © 2017年 Alexcai. All rights reserved.
//

import Cocoa

class Student: NSObject {
    var name = "Alexiuce"
    var courceName = "macOS"
    var courceCreateDate = Date()

}
